/* ═══════════════════════════════════════════
   16. Monaco 加载、降级模式与 boot()
   ═══════════════════════════════════════════
   由渲染层单体文件拆分而来。各模块按 index.html 里的顺序加载，
   共享同一份全局词法作用域（state / el / API / 各工具函数）。
   ═══════════════════════════════════════════ */
/* ═══════════════════════════════════════════
   启动
   ═══════════════════════════════════════════ */

/* Monaco 加载：本地优先，失败自动降级 CDN。
   两条路都走不通时也必须把界面启动起来，避免出现「窗口能开但点什么都没反应」。 */
const MONACO_LOCAL = 'vendor/monaco';
const MONACO_CDN = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs';

function loadMonaco(paths, onFail) {
    try {
        require.config({ paths: { vs: paths } });
        require(['vs/editor/editor.main'],
            () => onFail ? onFail(false) : null,
            err => { if (onFail) onFail(true, err); });
    } catch (e) {
        if (onFail) onFail(true, e);
    }
}

function startMonaco() {
    if (typeof require === 'undefined' || typeof require.config !== 'function') {
        // 本地 loader 没起来，改用 CDN 的 loader
        const s = document.createElement('script');
        s.src = MONACO_CDN + '/loader.js';
        s.onload = () => loadMonaco(MONACO_CDN, (failed) => {
            if (failed) startDegraded();
            else setupEditor();
        });
        s.onerror = startDegraded;
        document.head.appendChild(s);
        return;
    }
    loadMonaco(MONACO_LOCAL, (failed) => {
        if (!failed) { setupEditor(); return; }
        // 本地失败 → 试 CDN
        loadMonaco(MONACO_CDN, (failed2) => {
            if (failed2) startDegraded();
            else setupEditor();
        });
    });
}

/* 降级模式：Monaco 完全不可用时，用一个纯 textarea 顶上，
   保证文件依然能打开、编辑、保存、运行。 */
function startDegraded() {
    const host = document.getElementById('editor');
    if (!host) return;
    host.innerHTML = '';
    const ta = document.createElement('textarea');
    ta.id = 'fallback-textarea';
    ta.spellcheck = false;
    ta.style.cssText = 'width:100%;height:100%;background:#0d0d13;color:#d7d7e2;border:none;outline:none;padding:14px 18px;'
        + 'font-family:var(--mono);font-size:13px;line-height:1.65;resize:none;';
    host.appendChild(ta);

    // 用最小适配层模拟 monaco 实例，让上层逻辑无需分支
    editor = {
        __fallback: true,
        _model: null,
        getModel: () => editor._model,
        setModel(m) {
            editor._model = m;
            ta.value = m ? m.getValue() : '';
        },
        getValue: () => ta.value,
        setValue(v) { ta.value = v; },
        updateOptions() {}, layout() {}, focus() { ta.focus(); },
        saveViewState: () => null,
        restoreViewState() {},
        getPosition: () => ({ lineNumber: 1, column: 1 }),
        setPosition() {}, revealLineInCenter() {},
        hasTextFocus: () => document.activeElement === ta,
        getAction: () => ({ run: () => {} }),
        onDidChangeCursorPosition: () => ({ dispose() {} }),
        onDidChangeModelContent: () => ({ dispose() {} }),
        onDidChangeModelLanguage: () => ({ dispose() {} }),
        onDidFocusEditorText: () => ({ dispose() {} }),
        trigger() {}
    };
    // 全局 monaco 桩，供标签页创建模型
    window.monaco = {
        Uri: { parse: s => ({ toString: () => s, __s: s }) },
        editor: {
            createModel: (value, languageId, uri) => ({
                getValue: () => value,
                setValue(v) { value = v; },
                getLanguageId: () => languageId || 'plaintext',
                uri,
                onDidChangeContent(cb) { this._cb = cb; },
                _fire() { this._cb && this._cb(); },
                dispose() {}
            }),
            getModel: () => null,
            defineTheme() {}, setTheme() {}, create: () => editor
        },
        languages: { getLanguages: () => [] }
    };
    // textarea 输入同步回“模型”
    ta.addEventListener('input', () => {
        const t = state.tabs[state.active];
        if (t && t.model) { t.model.setValue(ta.value); if (t.model._fire) t.model._fire(); }
    });

    boot(true);
}

function setupEditor() {
    monaco.editor.defineTheme('sysbin-dark', {
        base: 'vs-dark', inherit: true, rules: [],
        colors: {
            'editor.background': '#0d0d13',
            'editor.foreground': '#d7d7e2',
            'editor.lineHighlightBackground': '#16161f',
            'editorCursor.foreground': '#6c9ef8',
            'editor.selectionBackground': '#2a3550',
            'editorLineNumber.foreground': '#3d3d4d',
            'editorLineNumber.activeForeground': '#8a8a9c',
            'editorIndentGuide.background1': '#21212c',
            'editorGutter.background': '#0d0d13'
        }
    });
    monaco.editor.defineTheme('sysbin-light', {
        base: 'vs', inherit: true, rules: [],
        colors: {
            'editor.background': '#ffffff',
            'editor.lineHighlightBackground': '#f4f4f8',
            'editorCursor.foreground': '#4a7ad6',
            'editor.selectionBackground': '#d3e2ff'
        }
    });

    editor = monaco.editor.create($('editor'), {
        value: '',
        language: 'plaintext',
        theme: 'sysbin-dark',
        automaticLayout: true,
        minimap: { enabled: true, renderCharacters: false },
        fontSize: 13,
        fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
        lineNumbers: 'on',
        folding: true,
        renderLineHighlight: 'all',
        bracketPairColorization: { enabled: true },
        suggestOnTriggerCharacters: true,
        quickSuggestions: true,
        wordBasedSuggestions: 'currentDocument',
        smoothScrolling: true,
        cursorBlinking: 'smooth',
        cursorSmoothCaretAnimation: 'on',
        mouseWheelZoom: true,
        scrollBeyondLastLine: false,
        padding: { top: 10 },
        tabSize: 4,
        insertSpaces: true,
        renderWhitespace: 'selection',
        scrollbar: { verticalScrollbarSize: 11, horizontalScrollbarSize: 11, useShadows: false },
        stickyScroll: { enabled: false }
    });

    boot(false);
}

async function boot(degraded) {
    bindEditorEvents();
    bindHex();
    bindMenus();
    bindPalette();
    bindTerminal();
    bindShortcuts();
    bindResizers();
    bindPanels();
    bindActivityBar();
    bindTitlebar();
    bindWelcome();
    bindExplorer();
    bindTools();
    bindAbout();
    bindSettings();
    bindSearch();
    bindPlugins();          // 插件页面与市场（renderer/plugins.js）
    showView('explorer');
    refreshPlugins();       // 后台拉一次插件清单，顺带把插件命令塞进命令面板

    // 载入设置
    try {
        const loaded = await API.loadSettings();
        state.settings = Object.assign({}, DEFAULT_SETTINGS);
        if (loaded && loaded.ok && loaded.data && typeof loaded.data === 'object') {
            Object.keys(DEFAULT_SETTINGS).forEach(k => { if (loaded.data[k] !== undefined) state.settings[k] = loaded.data[k]; });
        }
        if (loaded && loaded.path) { state.env = { settingsPath: loaded.path }; }
    } catch (e) {
        state.settings = Object.assign({}, DEFAULT_SETTINGS);
    }
    state.suppress = true; applyAll(); state.suppress = false;
    renderRecent();
    restoreBackdrop();      // 恢复上次设置的背景（要等设置载入完，applyTheme 才不会拿到空的 state.settings）

    // 环境信息
    try {
        const info = await API.envInfo();
        state.env = Object.assign(state.env || {}, info);
        $('about-ver').textContent = 'v' + info.appVersion;
        showPyCurrent(info.pythonPath);
        $('set-file-path').textContent = info.settingsPath || '（未知）';
        $('set-file-path').title = info.settingsPath || '';
        if (state.settings.pythonPath) {
            const r = await API.setPythonPath(state.settings.pythonPath);
            showPyCurrent(r.pythonPath);
        }
    } catch (e) {}

    // 初始文档
    if (state.tabs.length === 0) {
        untitledSeq = 0;
        const t = newUntitled('js');
        t.model.setValue(
`// 欢迎使用 Sysbin Studio Code
// Ctrl+Shift+P 打开命令面板 · Ctrl+P 快速打开文件

function greet(name) {
    return \`你好，\${name}！\`;
}

console.log(greet('Sysbin'));

// F5 运行当前文件，结果会显示在下方终端
`);
        t.dirty = false;
        renderTabs();
    }

    updateStatusPaths();
    logOut('Sysbin Studio Code 已就绪', 'info');

    /* 接收外部打开请求。
       先注册增量监听，再取走冷启动攒下的路径，顺序不能反：
       反了的话，take 与首批 push 之间存在空窗，那批文件会被丢掉。*/
    try {
        API.onOpenTargets((list) => { openTargets(list); });
        const initial = await API.takeOpenTargets();
        if (initial && initial.length) await openTargets(initial);
    } catch (e) {
        logOut('外部打开通道异常：' + ((e && e.message) || e), 'err');
    }

    if (degraded) {
        logOut('⚠ Monaco 内核未能加载，已切换到简易编辑模式（仍可编辑 / 保存 / 运行）', 'warn');
        toast('Monaco 未加载，已进入简易编辑模式', 'warn', 5000);
    } else {
        logOut('Monaco Editor 已加载（本地资源）', 'info');
    }
    if (state.env) {
        logOut('Electron ' + state.env.electron + ' · Node ' + state.env.node + ' · Chromium ' + state.env.chrome, 'info');
        logOut('Python 内核: ' + (state.env.pythonPath || '未探测到'), state.env.pythonPath ? 'info' : 'warn');
    }
    el.stPos.textContent = '行 1，列 1';
}

function updateStatusPaths() {
    el.stFolder.textContent = state.root ? baseOf(state.root) : '无文件夹';
    el.stFolder.title = state.root || '';
}
