const path=require('path');
console.log('__filename =', __filename);
console.log('argv =', JSON.stringify(process.argv));
