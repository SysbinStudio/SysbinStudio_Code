/* ═══════════════════════════════════════════
   18. AI 助手视图

   左侧活动栏新增「AI」视图：
     · 用户自己填写接口地址 / API Key / 模型 / 温度（保存到 config.json 的
       settings.ai，本机持久化）
     · 对话请求经主进程 ai 服务转发（绕开渲染层 CSP），支持流式输出
     · 可把「当前打开的文件」作为上下文发给模型
     · 模型返回代码块后，一键（或开启「自动写入」后自动）写回目标文件

   协议：OpenAI 兼容的 /chat/completions。
   ═══════════════════════════════════════════ */
/* ═════════════════════════════════════════
   18. AI 助手
   ═════════════════════════════════════════ */

const AI_SYS_PROMPT = '你是 Sysbin Studio Code 内置的编程助手。'
    + '请用简体中文回答。'
    + '如果需要修改或新建文件，请把完整代码放在一个 ```语言 代码块 中返回，'
    + '并简要说明改了什么。不要编造文件系统中不存在的路径。';

const aiState = {
    built: false,
    messages: [],        // [{ role:'user'|'assistant', content }]
    targetPath: '',       // 作为上下文 / 写入目标 的文件路径
    includeContext: true,
    autoApply: false,
    streaming: false,
    reqId: '',
    streamEl: null,
    pendingCode: null
};

/* settings.ai 落点，确保永远有对象可用 */
function aiCfg() {
    if (!state.settings) state.settings = {};
    if (!state.settings.ai || typeof state.settings.ai !== 'object') state.settings.ai = {};
    if (state.settings.ai.temperature === undefined) state.settings.ai.temperature = 0.7;
    return state.settings.ai;
}

function aiNextReq() { return 'ai-' + Date.now() + '-' + Math.floor(Math.random() * 1e4); }

/* ─────────── 渲染（首次建骨架，之后只刷新动态部分） ─────────── */

function renderAI() {
    const box = $('view-ai');
    if (!box) return;
    if (!aiState.built) {
        box.innerHTML = `
            <div class="ai-wrap">
                <div class="ai-config" id="ai-config">
                    <div class="ai-config-head">
                        <span class="ai-config-title">AI 配置</span>
                        <button class="sb-mini" id="ai-cfg-toggle" title="收起/展开">▾</button>
                    </div>
                    <div class="ai-config-body">
                        <div class="ai-row">
                            <label>接口地址</label>
                            <input id="ai-baseurl" placeholder="https://api.openai.com/v1" spellcheck="false" />
                        </div>
                        <div class="ai-row">
                            <label>API Key</label>
                            <input id="ai-apikey" type="password" placeholder="sk-...（仅保存在本机 config.json）" spellcheck="false" />
                        </div>
                        <div class="ai-row ai-row-2">
                            <div><label>模型</label><input id="ai-model" placeholder="gpt-4o-mini" spellcheck="false" /></div>
                            <div><label>温度</label><input id="ai-temp" type="number" min="0" max="2" step="0.1" value="0.7" /></div>
                        </div>
                        <div class="ai-config-actions">
                            <button class="btn btn-primary btn-sm" id="ai-cfg-save">保存配置</button>
                            <span class="ai-cfg-status" id="ai-cfg-status"></span>
                        </div>
                        <div class="ai-hint">支持任意 OpenAI 兼容接口：OpenAI、DeepSeek、通义千问、LM Studio、Ollama(/v1)、vLLM 等。</div>
                    </div>
                </div>

                <div class="ai-msgs" id="ai-msgs">
                    <div class="ai-empty">在上方填写接口后，直接问 AI 关于代码的问题，或让它帮你改写文件。</div>
                </div>

                <div class="ai-target">
                    <label class="ai-attach"><input type="checkbox" id="ai-attach" checked /> 附带当前文件内容</label>
                    <select id="ai-target-sel" title="作为上下文 / 写入目标"></select>
                    <label class="ai-auto"><input type="checkbox" id="ai-auto" /> 自动写入</label>
                </div>

                <div class="ai-input-row">
                    <textarea id="ai-input" placeholder="问 AI 任何关于代码的问题…（Enter 发送，Shift+Enter 换行）" spellcheck="false"></textarea>
                </div>
                <div class="ai-send-row">
                    <button class="btn btn-primary btn-sm" id="ai-send">发送</button>
                    <button class="btn btn-outline btn-sm" id="ai-stop" style="display:none">停止</button>
                    <div class="ai-flex"></div>
                    <button class="btn btn-outline btn-sm" id="ai-clear">清空对话</button>
                </div>

                <div class="ai-apply" id="ai-apply" style="display:none">
                    <span class="ai-apply-tip">AI 返回了可写入的代码：</span>
                    <button class="btn btn-primary btn-sm" id="ai-apply-btn">写入 <span id="ai-apply-name"></span></button>
                </div>
            </div>`;
        aiBind(box);
        aiState.built = true;
    }
    aiRefreshTargets();
    aiLoadCfgUI();
}

function aiBind(box) {
    $('ai-cfg-save').addEventListener('click', aiSaveCfg);
    $('ai-cfg-toggle').addEventListener('click', () => {
        const b = $('ai-config');
        b.classList.toggle('collapsed');
        $('ai-cfg-toggle').textContent = b.classList.contains('collapsed') ? '▸' : '▾';
    });
    const attach = $('ai-attach');
    attach.addEventListener('change', () => { aiState.includeContext = attach.checked; });
    $('ai-auto').addEventListener('change', e => { aiState.autoApply = e.target.checked; });
    $('ai-target-sel').addEventListener('change', e => { aiState.targetPath = e.target.value; });
    const input = $('ai-input');
    input.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); aiSend(); }
    });
    $('ai-send').addEventListener('click', aiSend);
    $('ai-stop').addEventListener('click', aiStop);
    $('ai-clear').addEventListener('click', aiClear);
    $('ai-apply-btn').addEventListener('click', aiApply);
}

function aiLoadCfgUI() {
    const c = aiCfg();
    const set = (id, v) => { const elx = $(id); if (elx && v !== undefined && v !== null) elx.value = v; };
    set('ai-baseurl', c.baseURL);
    set('ai-apikey', c.apiKey);
    set('ai-model', c.model);
    set('ai-temp', c.temperature);
}

function aiSaveCfg() {
    const c = aiCfg();
    c.baseURL = ($('ai-baseurl').value || '').trim();
    c.apiKey = ($('ai-apikey').value || '').trim();
    c.model = ($('ai-model').value || '').trim();
    const t = parseFloat($('ai-temp').value);
    c.temperature = isNaN(t) ? 0.7 : Math.max(0, Math.min(2, t));
    API.saveSettings(state.settings).then(r => {
        const st = $('ai-cfg-status');
        if (st) {
            st.textContent = (r && r.ok) ? '已保存' : ('保存失败：' + ((r && r.error) || ''));
            st.style.color = (r && r.ok) ? 'var(--ok)' : 'var(--err)';
            setTimeout(() => { if (st) st.textContent = ''; }, 2600);
        }
    });
    toast('AI 配置已保存到本机', 'ok', 1600);
}

/* 刷新「目标文件」下拉：默认选中当前活动标签 */
function aiRefreshTargets() {
    const sel = $('ai-target-sel');
    if (!sel) return;
    const attach = $('ai-attach');
    sel.textContent = '';
    if (!state.tabs.length) {
        sel.innerHTML = '<option value="">（未打开文件）</option>';
        aiState.targetPath = '';
        if (attach) attach.disabled = true;
        return;
    }
    if (attach) attach.disabled = false;
    for (const tab of state.tabs) {
        const p = tab.path || (tab.name ? '未命名：' + tab.name : '');
        if (!p) continue;
        const o = document.createElement('option');
        o.value = p;
        o.textContent = tab.path ? baseOf(tab.path) : tab.name;
        sel.appendChild(o);
    }
    const t = activeTab();
    const def = (t && (t.path || t.name)) || (sel.options.length ? sel.options[0].value : '');
    if (def) { sel.value = def; aiState.targetPath = def; }
}

/* ─────────── 对话 ─────────── */

function aiAddMsg(role, content) {
    const box = $('ai-msgs');
    const empty = box.querySelector('.ai-empty');
    if (empty) empty.remove();
    const wrap = document.createElement('div');
    wrap.className = 'ai-msg ' + (role === 'user' ? 'ai-user' : 'ai-assistant');
    const bubble = document.createElement('div');
    bubble.className = 'ai-bubble';
    if (role === 'user') bubble.innerHTML = escapeHtml(content).replace(/\n/g, '<br>');
    else if (content) bubble.innerHTML = aiFormat(content);
    wrap.appendChild(bubble);
    box.appendChild(wrap);
    aiScroll();
    return bubble;
}

/* 把文本渲染成「自然语言段落 + 代码块」；代码块用 ``` 包裹 */
function aiFormat(text) {
    const re = /```(\w*)\n?([\s\S]*?)```/g;
    let out = '';
    let last = 0, m;
    while ((m = re.exec(text)) !== null) {
        const before = text.slice(last, m.index);
        if (before.trim()) out += `<div class="ai-text">${escapeHtml(before).replace(/\n/g, '<br>')}</div>`;
        out += `<pre class="ai-code"><code>${escapeHtml(m[2])}</code></pre>`;
        last = re.lastIndex;
    }
    const after = text.slice(last);
    if (after.trim()) out += `<div class="ai-text">${escapeHtml(after).replace(/\n/g, '<br>')}</div>`;
    return out || '<div class="ai-text"></div>';
}

async function aiSend() {
    if (aiState.streaming) return;
    const cfg = aiCfg();
    const input = $('ai-input');
    const text = input.value.trim();
    if (!text) return;
    if (!cfg.apiKey && !cfg.baseURL) {
        toast('请先在上方填写接口地址与 API Key', 'warn', 3200);
        const c = $('ai-config'); if (c && c.classList.contains('collapsed')) $('ai-cfg-toggle').click();
        return;
    }
    input.value = '';

    aiAddMsg('user', text);
    aiState.messages.push({ role: 'user', content: text });

    const messages = [{ role: 'system', content: AI_SYS_PROMPT }];
    if (aiState.includeContext && aiState.targetPath && /[\\/]/.test(aiState.targetPath)) {
        const content = await aiTargetContent(aiState.targetPath);
        if (content != null) {
            messages.push({ role: 'system', content: `当前编辑文件：${aiState.targetPath}\n\n\`\`\`\n${content}\n\`\`\`` });
        }
    }
    aiState.messages.forEach(mm => messages.push({ role: mm.role, content: mm.content }));
    messages.push({ role: 'user', content: text });

    const bubble = aiAddMsg('assistant', '');
    aiState.streamEl = bubble;
    aiState.streaming = true;
    aiState.reqId = aiNextReq();
    aiShowStop(true);

    API.aiChat({
        baseURL: cfg.baseURL,
        apiKey: cfg.apiKey,
        model: cfg.model || 'gpt-4o-mini',
        temperature: (typeof cfg.temperature === 'number') ? cfg.temperature : 0.7,
        messages,
        requestId: aiState.reqId
    }).then(res => {
        if (res && !res.ok && !res.aborted) {
            const elx = aiState.streamEl;
            if (elx) { elx.textContent = '⚠ ' + (res.error || '请求失败'); elx.classList.add('ai-err'); }
        }
    }).catch(e => {
        const elx = aiState.streamEl;
        if (elx) { elx.textContent = '⚠ ' + String((e && e.message) || e); elx.classList.add('ai-err'); }
    }).finally(() => {
        aiState.streaming = false;
        aiShowStop(false);
    });
}

function aiStop() {
    if (aiState.reqId) API.aiAbort(aiState.reqId);
    aiState.streaming = false;
    aiShowStop(false);
    if (aiState.streamEl) {
        const cur = aiState.streamEl.textContent;
        aiState.streamEl.innerHTML = aiFormat(cur + '\n\n[已停止]');
    }
}

function aiClear() {
    aiState.messages = [];
    aiState.pendingCode = null;
    $('ai-msgs').innerHTML = '<div class="ai-empty">对话已清空。</div>';
    const ap = $('ai-apply'); if (ap) ap.style.display = 'none';
}

/* 取目标文件内容：优先用已打开标签的模型，否则读盘 */
async function aiTargetContent(path) {
    const t = state.tabs.find(x => x.path === path);
    if (t && t.model) return t.model.getValue();
    try { const r = await API.readFile(path); if (r && r.ok) return r.content; } catch (e) {}
    return null;
}

/* ─────────── 流式事件 ─────────── */

function aiHandleToken(d) {
    if (!d || d.requestId !== aiState.reqId) return;
    if (aiState.streamEl) aiState.streamEl.textContent += d.delta;
    aiScroll();
}

function aiHandleDone(d) {
    if (!d || d.requestId !== aiState.reqId) return;
    if (aiState.streamEl) {
        aiState.streamEl.innerHTML = aiFormat(d.content || '');
        aiState.streamEl.classList.remove('ai-err');
    }
    aiState.streaming = false;
    aiShowStop(false);
    aiState.messages.push({ role: 'assistant', content: d.content || '' });
    aiUpdateApply(d.content || '');
    aiScroll();
}

/* 从 AI 回复里抽出第一个代码块（作为可写回的内容） */
function aiExtractCode(content) {
    const m = /```(?:\w*)\n?([\s\S]*?)```/.exec(content || '');
    if (m) return m[1].replace(/\n$/, '');
    return null;
}

function aiUpdateApply(content) {
    const code = aiExtractCode(content);
    const ap = $('ai-apply');
    const name = $('ai-apply-name');
    if (code != null && aiState.targetPath && /[\\/]/.test(aiState.targetPath)) {
        aiState.pendingCode = code;
        if (name) name.textContent = baseOf(aiState.targetPath);
        if (ap) ap.style.display = 'flex';
        if (aiState.autoApply) aiApply();
    } else {
        aiState.pendingCode = null;
        if (ap) ap.style.display = 'none';
    }
}

/* 把 AI 返回的代码写回目标文件 */
async function aiApply() {
    const code = aiState.pendingCode;
    const path = aiState.targetPath;
    if (code == null || !path || !/[\\/]/.test(path)) {
        toast('请选择一个已保存的文件作为写入目标', 'warn', 3200);
        return;
    }
    const res = await API.writeFile({ path, content: code });
    if (!res.ok) { toast('写入失败：' + res.error, 'err', 3600); return; }
    const t = state.tabs.find(x => x.path === path);
    if (t && t.model) { t.model.setValue(code); t.dirty = true; renderTabs(); renderTree(); }
    pluginsEmit('file:save', { path });
    toast('已写入 ' + baseOf(path), 'ok', 2000);
    logOut('AI 已将代码写入：' + path, 'info');
}

function aiShowStop(on) {
    const s = $('ai-stop'); if (s) s.style.display = on ? '' : 'none';
    const send = $('ai-send'); if (send) send.disabled = on;
}

function aiScroll() {
    const box = $('ai-msgs');
    if (box) box.scrollTop = box.scrollHeight;
}

/* 命令面板入口：用 AI 改写当前文件（把当前文件作为上下文，预填指令） */
function aiRewriteCurrent() {
    showView('ai');
    const t = activeTab();
    if (!t) { toast('请先打开一个文件', 'warn'); return; }
    if (!t.path) { toast('请先保存当前文件，再让它改写', 'warn'); return; }
    aiState.targetPath = t.path;
    const sel = $('ai-target-sel');
    if (sel) sel.value = t.path;
    const attach = $('ai-attach');
    if (attach) { attach.checked = true; aiState.includeContext = true; }
    const input = $('ai-input');
    if (input) {
        input.value = '请改进并补全这个文件，修复明显问题，然后把完整代码放在一个代码块里返回。';
        setTimeout(() => input.focus(), 60);
    }
    toast('已载入当前文件作为上下文，发送即可让 AI 改写', 'info', 2600);
}

/* 流式事件在脚本加载时就注册，保证 token 不会丢 */
API.onAiToken(d => aiHandleToken(d));
API.onAiDone(d => aiHandleDone(d));
